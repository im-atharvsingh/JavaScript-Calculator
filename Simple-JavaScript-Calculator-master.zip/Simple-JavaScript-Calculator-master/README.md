# [Simple Javascript Calculator](https://harsh98trivedi.github.io/Simple-JavaScript-Calculator) 

A simple JavaScript Calculator made by [Harsh Trivedi](https://harsh98trivedi.github.io)

![Simple Javascript Calculator](https://raw.githubusercontent.com/harsh98trivedi/Simple-JavaScript-Calculator/master/meta.jpg)
